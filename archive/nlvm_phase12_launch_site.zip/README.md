# NLVM – Natural Language Virtual Machine

NLVM lets anyone write programs using plain English. No syntax, no code — just logic in your own words.

## ✨ Example
```
Set x to 5
Add x and 10 and store result in total
Print total
```

## 🚀 How to Use
1. Write your program in `program.nl`
2. Compile using `nlp_compiler.py`
3. Execute using `nlvm.py`

## 🧠 Features
- Human-friendly programming
- File I/O, API calls, math, variables
- Built-in compiler + runtime

## 📂 Folders
- `examples/`: Sample `.nl` programs
- `compiler/`: NLP-based English to bytecode compiler
- `runtime/`: Bytecode virtual machine

## 💬 License
MIT – Open for the world to learn and build on.

> Code is dead. Language lives.