from runtime import Interpreter

if __name__ == "__main__":
    program = [
        "Create a dictionary called user with name as John and age as 30",
        "Print user.name",
        "Print user.age",
        "Create a variable called x and set it to 5",
        "Create a variable called y and set it to 10",
        "Add x and y and store the result in z",
        "Print z"
    ]
    
    interpreter = Interpreter()
    interpreter.run(program)