class Interpreter:
    def __init__(self):
        self.env = {}

    def run(self, lines):
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith("Create a variable called"):
                self._handle_assignment(line)
            elif line.startswith("Add"):
                self._handle_addition(line)
            elif line.startswith("Print"):
                self._handle_print(line)
            elif line.startswith("Create a dictionary called"):
                self._handle_dict_creation(line)
            i += 1

    def _handle_assignment(self, line):
        parts = line.split()
        var_name = parts[4]
        value = self._parse_value(parts[-1])
        self.env[var_name] = value

    def _handle_addition(self, line):
        parts = line.split()
        x = self._get_value(parts[1])
        y = self._get_value(parts[3])
        result_var = parts[-1]
        self.env[result_var] = x + y

    def _handle_print(self, line):
        expr = line.split("Print", 1)[1].strip()
        if "." in expr:
            var, key = expr.split(".")
            val = self.env.get(var, {})
            print(val.get(key, f"{key} not found in {var}"))
        else:
            print(self.env.get(expr, f"{expr} not defined"))

    def _handle_dict_creation(self, line):
        # e.g., Create a dictionary called user with name as John and age as 30
        parts = line.split("with")
        dict_name = parts[0].split("called")[1].strip()
        key_values = parts[1].split("and")
        result = {}
        for pair in key_values:
            if "as" in pair:
                k, v = pair.strip().split("as")
                k = k.strip()
                v = self._parse_value(v.strip())
                result[k] = v
        self.env[dict_name] = result

    def _parse_value(self, val):
        try:
            return int(val)
        except:
            return val.strip('"').strip("'")

    def _get_value(self, token):
        return self.env.get(token, self._parse_value(token))