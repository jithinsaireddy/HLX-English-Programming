import re

class Interpreter:
    def __init__(self):
        self.env = {}
        self.functions = {}

    def run(self, lines):
        i = 0
        while i < len(lines):
            line = lines[i].strip().lower()
            try:
                if line.startswith("define a function called"):
                    func_name, param = self._parse_function_header(line)
                    i += 1
                    block = []
                    while i < len(lines) and lines[i].startswith("    "):
                        block.append(lines[i].strip())
                        i += 1
                    self.functions[func_name] = (param, block)
                    continue
                elif line.startswith("call"):
                    self._handle_function_call(line)
                elif "create a list called" in line and "with values" in line:
                    self._handle_list_creation(line)
                elif "create a variable" in line and "set it to" in line:
                    self._handle_variable(line)
                elif line.startswith("print"):
                    self._handle_print(line)
                elif "get the length of list" in line:
                    self._handle_length(line)
                elif "add" in line and "and" in line and "store the result in" in line:
                    self._handle_addition(line)
                else:
                    print(f"Unrecognized instruction: '{line}'")
            except Exception as e:
                print(f"Error: {str(e)}")
            i += 1

    def _parse_function_header(self, line):
        match = re.search(r"define a function called (.+?) with input (.+):", line)
        if match:
            return match.group(1).strip(), match.group(2).strip()
        raise ValueError("Invalid function definition")

    def _handle_function_call(self, line):
        match = re.search(r"call (.+?) with value (.+)", line)
        if match:
            func_name = match.group(1).strip()
            arg_value = self._parse_value(match.group(2).strip())
            if func_name in self.functions:
                param, block = self.functions[func_name]
                func_env = {param: arg_value}
                self.run_with_env(block, func_env)
            else:
                raise NameError(f"Function '{func_name}' not defined")

    def run_with_env(self, lines, local_env):
        for line in lines:
            line = line.strip().lower()
            if line.startswith("print"):
                expr = line.replace("print", "").strip()
                print(local_env.get(expr, self.env.get(expr, f"Variable '{expr}' is not defined")))

    def _handle_variable(self, line):
        match = re.search(r"create a variable called (.+?) and set it to (.+)", line)
        if match:
            var_name = match.group(1).strip()
            value = self._parse_value(match.group(2).strip())
            self.env[var_name] = value

    def _handle_list_creation(self, line):
        match = re.search(r"create a list called (.+?) with values (.+)", line)
        if match:
            list_name = match.group(1).strip()
            values = [self._parse_value(x.strip()) for x in match.group(2).split(",")]
            self.env[list_name] = values

    def _handle_length(self, line):
        match = re.search(r"get the length of list (.+?) and store it in (.+)", line)
        if match:
            list_name = match.group(1).strip()
            var_name = match.group(2).strip()
            if list_name not in self.env or not isinstance(self.env[list_name], list):
                raise ValueError(f"'{list_name}' is not a list")
            self.env[var_name] = len(self.env[list_name])

    def _handle_addition(self, line):
        match = re.search(r"add (.+?) and (.+?) and store the result in (.+)", line)
        if match:
            x = self._get_value(match.group(1).strip())
            y = self._get_value(match.group(2).strip())
            result_var = match.group(3).strip()
            self.env[result_var] = x + y

    def _handle_print(self, line):
        expr = line.replace("print", "").strip()
        if expr not in self.env:
            raise NameError(f"Variable '{expr}' is not defined")
        print(self.env[expr])

    def _parse_value(self, val):
        val = val.strip(""'")
        if val.lower() == "true":
            return True
        elif val.lower() == "false":
            return False
        try:
            return int(val)
        except ValueError:
            try:
                return float(val)
            except ValueError:
                return val

    def _get_value(self, token):
        return self.env.get(token, self._parse_value(token))