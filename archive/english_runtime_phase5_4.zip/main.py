from runtime import Interpreter

if __name__ == "__main__":
    program = [
        "Define a function called greet with input name:",
        "    Print name",
        "Call greet with value John",
        "Create a list called numbers with values 5, 10, 15",
        "Get the length of list numbers and store it in count",
        "Print count",
        "Add 100 and 200 and store the result in total",
        "Print total",
        "Print undefined_variable"  # This should raise a friendly error
    ]
    
    interpreter = Interpreter()
    interpreter.run(program)