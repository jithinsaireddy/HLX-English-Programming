from flask import Flask, render_template, request
import re

app = Flask(__name__)

def compile_and_run(nl_code):
    env = {}
    lines = nl_code.strip().split("\n")
    output = []
    for line in lines:
        line = line.strip().lower()
        try:
            if "set" in line:
                m = re.search(r"(?:create a variable )?set (.+?) (?:to|as) (.+)", line)
                if m:
                    env[m.group(1).strip()] = parse_value(m.group(2).strip())
            elif "add" in line:
                m = re.search(r"add (.+?) and (.+?) and store (?:the )?(?:result|outcome) in (.+)", line)
                if m:
                    x = env.get(m.group(1).strip(), 0)
                    y = env.get(m.group(2).strip(), 0)
                    env[m.group(3).strip()] = x + y
            elif "print" in line or "show" in line:
                m = re.search(r"(?:print|show|display) (.+)", line)
                if m:
                    var = m.group(1).strip().strip("?")
                    output.append(str(env.get(var, f"{var} not defined")))
        except Exception as e:
            output.append(f"Error: {str(e)}")
    return "\n".join(output)

def parse_value(val):
    try:
        return int(val)
    except:
        try:
            return float(val)
        except:
            return val

@app.route("/", methods=["GET", "POST"])
def index():
    result = ""
    if request.method == "POST":
        code = request.form["code"]
        result = compile_and_run(code)
    return render_template("index.html", output=result)

if __name__ == "__main__":
    app.run(debug=True)