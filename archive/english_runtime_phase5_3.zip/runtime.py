import re

class Interpreter:
    def __init__(self):
        self.env = {}

    def run(self, lines):
        for line in lines:
            line = line.strip().lower()
            try:
                if "create a variable" in line and "set it to" in line:
                    self._handle_variable(line)
                elif "create a list called" in line and "with values" in line:
                    self._handle_list_creation(line)
                elif line.startswith("print"):
                    self._handle_print(line)
                elif "get the length of list" in line:
                    self._handle_length(line)
                elif "get the maximum value in list" in line:
                    self._handle_maximum(line)
                else:
                    print(f"Unrecognized instruction: '{line}'")
            except Exception as e:
                print(f"Error: {str(e)}")

    def _handle_variable(self, line):
        match = re.search(r"create a variable called (.+?) and set it to (.+)", line)
        if match:
            var_name = match.group(1).strip()
            value = self._parse_value(match.group(2).strip())
            self.env[var_name] = value

    def _handle_list_creation(self, line):
        match = re.search(r"create a list called (.+?) with values (.+)", line)
        if match:
            list_name = match.group(1).strip()
            values = [self._parse_value(x.strip()) for x in match.group(2).split(",")]
            self.env[list_name] = values

    def _handle_length(self, line):
        match = re.search(r"get the length of list (.+?) and store it in (.+)", line)
        if match:
            list_name = match.group(1).strip()
            var_name = match.group(2).strip()
            if list_name not in self.env or not isinstance(self.env[list_name], list):
                raise ValueError(f"'{list_name}' is not a list")
            self.env[var_name] = len(self.env[list_name])

    def _handle_maximum(self, line):
        match = re.search(r"get the maximum value in list (.+?) and store it in (.+)", line)
        if match:
            list_name = match.group(1).strip()
            var_name = match.group(2).strip()
            if list_name not in self.env or not isinstance(self.env[list_name], list):
                raise ValueError(f"'{list_name}' is not a list")
            self.env[var_name] = max(self.env[list_name])

    def _handle_print(self, line):
        expr = line.replace("print", "").strip()
        if expr not in self.env:
            raise NameError(f"Variable '{expr}' is not defined")
        print(self.env[expr])

    def _parse_value(self, val):
        val = val.strip(""'")
        if val.lower() == "true":
            return True
        elif val.lower() == "false":
            return False
        try:
            return int(val)
        except ValueError:
            try:
                return float(val)
            except ValueError:
                return val