from runtime import Interpreter

if __name__ == "__main__":
    program = [
        "Create a list called items with values 10, 20, 30, 40",
        "Get the length of list items and store it in total_count",
        "Print total_count",
        "Get the maximum value in list items and store it in max_item",
        "Print max_item",
        "Create a variable called x and set it to 5",
        "Print y"  # This should raise an error for undefined variable
    ]
    
    interpreter = Interpreter()
    interpreter.run(program)